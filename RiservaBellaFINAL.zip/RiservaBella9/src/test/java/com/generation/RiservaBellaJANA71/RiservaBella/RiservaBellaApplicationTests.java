package com.generation.RiservaBellaJANA71.RiservaBella;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import com.generation.RiservaBellaJANA71.RiservaBella.dao.AniDao;

@SpringBootTest
class RiservaBellaApplicationTests {

	@Test
	void contextLoads() {
		// Test puliti perchè non si consegna un prodotto con codice test scritto 
	}

}
