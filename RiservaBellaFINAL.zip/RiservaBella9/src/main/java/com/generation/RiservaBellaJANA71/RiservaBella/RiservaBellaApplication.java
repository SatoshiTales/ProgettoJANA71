
package com.generation.RiservaBellaJANA71.RiservaBella;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiservaBellaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiservaBellaApplication.class, args);
	}

}
